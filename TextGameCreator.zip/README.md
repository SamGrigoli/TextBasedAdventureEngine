TEXT ADVENTURE GAME CREATOR
============================

GETTING STARTED (PLUG AND PLAY):
1. Extract the TextGameCreator.zip somewhere easily accessible 
2. Run "editor/GameEditor.exe" to create or edit games
3. Use File > New Game to create a new game
4. Build your world by adding rooms, items, enemies, and weapons
5. Save your game in the "data" folder

PLAYING A GAME:
1. Navigate to the "engine" folder in a terminal
2. Run "play.bat" (Windows)
3. Enter the name of the game you want to play
4. Enjoy!

HELP WHEN MAKING GAME:
1. When setting start room that is JUST THE ROOM YOU START IN, not the room you are currently editing
2. When making exits make sure you are connecting to other rooms using the ROOMID
   (Ex. north:roomid that you want to go to)
3. There is not a way to delete items and weapons after you place them in a room, you will have to delete the whole room. Bad design I know...
4. If you are ever confused as to how to interect with someting there is a "help" command in the game itself that should solve any issues
5. Enemies that you make in the game will attack you randomly after every action you make. After they die their text remains in the room. Also bad design...
6. You must equip a weapon to use it. You can check your weapons with the "weapons" command and you can check your currently equipped weapon with "status"

PLEASE ENJOY! ITS NOT PERFECT BUT I HOPE YOU CAN MAKE SOME COOL GAMES WITH THIS TOOL!