TEXT ADVENTURE GAME CREATOR
============================

GETTING STARTED:
1. Run "editor/GameEditor.exe" to create or edit games
2. Use File > New Game to create a new game
3. Build your world by adding rooms, items, enemies, and weapons
4. Save your game in the "games" folder

PLAYING A GAME:
1. Navigate to the "engine" folder in a terminal
2. Run "play.bat" (Windows) or "./play.sh" (Linux/Mac)
3. Enter the name of the game you want to play
4. Enjoy!

FOLDER STRUCTURE:
- editor/ : Contains the game editor
- games/  : Your saved games go here
- engine/ : Contains the game engine

REQUIREMENTS:
- Windows 10 or later (for Windows version)
- No additional software required